import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Validators, FormGroup, FormBuilder } from "@angular/forms";
import { StorageService } from '../core/services/storage.service';
import { LoginService } from '../core/services/login.service';
import { LoginObject } from '../core/models/login-object.model';
import { Session } from '../core/models/session.model';
import { LoginkondorService } from '../core/services/loginkondor.service';
import { Respuesta } from '../core/models/respuesta';

import Swal from 'sweetalert2';
import { User } from '../core/models/user.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {


  public loginForm: FormGroup;
  public submitted: Boolean = false;
  public error: { code: number, message: string } = null;
  public status;
  msgGeneral: Respuesta;
  messageForServe: string;
  visibilidadMsg: boolean = false;
  wsSubscription: Subscription;

  constructor(private formBuilder: FormBuilder,
    private authenticationService: LoginService,
    private storageService: StorageService,
    private loginKondor: LoginkondorService,
    private router: Router) {
    this.wsSubscription = this.loginKondor.createObservableSocket("ws://10.236.4.20:9000")
      .subscribe(
        data => {
          this.messageForServe = data;
          console.log(this.messageForServe)
        },
        err => console.log(err),
        () => console.log('The Observable stream is complete')
      );

  }

  ngOnInit() {
    this.storageService.removeCurrentSession();
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    })
  }

  ngOnDestroy(): void {
    this.closetSocket();
  }


  public submitLogin(): void {
    this.submitted = true;
    this.error = null;
    if (this.loginForm.valid) {
      console.log(this.loginForm.value);
      var loginObj = this.loginForm.value;
      /////

      //console.log(this.wsSubscription);
      //this.loginKondor._logger = "";
      this.status = this.loginKondor.sendMessage(loginObj.username, loginObj.password);/*.subscribe(res=>{
        this.status = res;
        console.log("Respuesta del sendMessage");
        console.log(this.status);
      });*/

      setTimeout(() => {
        if (this.status === "Send") {
          console.log(this.loginKondor._logger);
          this.messageForServe = this.loginKondor._logger;//this.status.__zone_symbol__value;

          if (this.messageForServe === "" || this.messageForServe === undefined) {
            this.visibilidadMsg = false;
          } else {
            this.msgGeneral = JSON.parse(this.messageForServe);
            console.log("this.msgGeneral");
            console.log(this.msgGeneral);
            this.visibilidadMsg = true;

            switch (this.msgGeneral.ErrorCode) {
              case 0:
                if (this.msgGeneral.HasPermission == 'T') {
                  this.authenticationService.login(new LoginObject(this.loginForm.value)).subscribe(
                    data => {
                      console.log(data);
                      if (data.token !== "") {
                        this.correctLogin(data);
                      } else {
                        this.error = { code: 404, message: "No login" };
                      }
                    },
                    error => {
                      this.error = error;
                    }
                  );
                  var session: Session = new Session();
                  session.token = "jshdgfjhsgdfjhsgjdfhgsjhfdgjshdgfjsgdf";
                  session.user = { id: -1, name: '', surname: '', email: '', username: '' };
                  this.correctLogin(session);
                } else {
                  Swal.fire({
                    title: 'Error',
                    type: 'error',
                    text: this.msgGeneral.ErrorMsg
                  });
                }

                break;
              default:
                //this.session = this.badSession();
                Swal.fire({
                  title: 'Error',
                  type: 'error',
                  text: this.msgGeneral.ErrorMsg
                });
                break;
            }
          }
        } else {
          Swal.fire({
            title: 'Error',
            type: 'error',
            text: 'Services Not Found'
          });
        }
      }, 1000);
    }
  }

  private correctLogin(data: Session) {
    this.storageService.setCurrentSession(data);
    this.router.navigate(['/swap']);
  }

  public sessionActivate(): boolean {
    return this.storageService.isAuthenticated();
  }

  closetSocket() {
    this.wsSubscription.unsubscribe();
    this.status = "";
  }

}
