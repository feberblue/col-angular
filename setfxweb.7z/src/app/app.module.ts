import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from '@angular/common/http';
import {MaterialAppModule} from './material.module';

//import { DataTablesModule } from 'angular-datatables';



import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginComponent } from './login/login.component';
import { Page404Component } from './core/components/page404/page404.component';
import { QueryerrorsComponent } from './core/components/queryerrors/queryerrors.component';
import { QueryokComponent } from './core/components/queryok/queryok.component';
import { ServiceStatusComponent } from './core/components/servicestatus/servicestatus.component';
import { DetailSetFxComponent } from './core/components/detailsetfx/detailsetfx.component';
import { NavbarComponent } from './core/template/navbar/navbar.component';
import { FooterComponent } from './core/template/footer/footer.component';
import { HomeComponent } from './home/home.component';
import { MessageAlertComponent } from './core/components/message/message.component';
import { ClientwsComponent } from './clientws/clientws.component';
import { AuthGuard } from './core/guard/auth.guard';
import { LoginService } from './core/services/login.service';
import { LoginkondorService } from './core/services/loginkondor.service';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    Page404Component,
    QueryerrorsComponent,
    QueryokComponent,
    ServiceStatusComponent,
    DetailSetFxComponent,
    NavbarComponent,
    FooterComponent,
    HomeComponent,
    MessageAlertComponent,
    ClientwsComponent,
    
  ],
  entryComponents:[MessageAlertComponent],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MaterialAppModule    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
