import { InjectionToken } from '@angular/core';

export const URL_QUERY_SWAP = new InjectionToken<string>('URL_QUERY_SWAP');
export const URL_LOGIN = new InjectionToken<string>('URL_LOGIN');
export const URL_PROCESS_SWAP = new InjectionToken<string>('URL_PROCESS_SWAP');