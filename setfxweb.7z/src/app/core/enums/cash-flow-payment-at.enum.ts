export enum CashFlowPaymentAt {
    B = "Beginning Bill",
    S = "Beginning (Simple)",
    E = "End",
    R = "End FRA BASIS"
}
