export enum AlertType {
    SUCCESS = "Success",
    ERROR = "Error",
    WARNING = "Warning"
}
