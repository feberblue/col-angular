export enum AmortizationType {
    N = "None",
    L = "Linear",
    A = "Constant Annuities",
    F = "Fixed Amount",
    V = "Variable Amount",
    O = "Other"
}
