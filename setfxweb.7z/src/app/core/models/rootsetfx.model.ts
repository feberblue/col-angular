import { SetFxModel } from './setfx.model';

export class RootSetFxModel {
    public root: SetFxModel[];
   
}