import { AlertType } from '../enums/alert.emun';

export class AlertModel {
    public messageText: string;
    public messageType: string;    
}