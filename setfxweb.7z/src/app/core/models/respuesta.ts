export interface Respuesta {
    ErrorCode: number;
    ErrorMsg: string;
    HasPermission: string;
}
