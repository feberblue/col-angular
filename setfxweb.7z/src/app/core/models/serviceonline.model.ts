export class ServiceOnLine {
    public service: string;
    public onLineColor: string;
}