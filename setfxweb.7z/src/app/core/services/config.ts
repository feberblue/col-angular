export const URL_SERVICE ={
    URL_LOGIN : "ws://10.236.4.20:9000",
    URL_QUERY_SWAP : "http://10.236.4.20:1421/blotter",    
    URL_PROCESS_SWAP:"http://10.236.4.20:1421/reprocess",
    URL_QUERY_FORWARD: "http://10.236.4.20:1421/forward"
}