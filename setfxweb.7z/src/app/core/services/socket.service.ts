import { Injectable, Inject } from '@angular/core';
import { WebSocketSubject } from 'rxjs/webSocket';
import { Observable } from 'rxjs';
import { Respuesta } from '../models/respuesta';
import { URL_LOGIN } from 'src/app/app.rutes';



@Injectable({
  providedIn: 'root'
})
export class SocketService {

  private _wsSubject: WebSocketSubject<any>;

  private get wsSubject() : WebSocketSubject<any>{
    const closed = !this._wsSubject || this._wsSubject.closed;
    if(closed){
      this._wsSubject = new WebSocketSubject(this.wsUrl);
    }
    return this._wsSubject;
  }

  get updateMessage$() : Observable<Respuesta>{
    return this.wsSubject.asObservable();
  }

  constructor(@Inject(URL_LOGIN) private readonly wsUrl: string) { }

  login(username : string, password: string){
    this.wsSubject.next({UserName: username, Password: password});
  }
}
